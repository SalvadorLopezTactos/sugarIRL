<?php 
$app_list_strings['tct_address_type_list'] = array (
  'ENVIO' => 'ENVIO',
  'FACTURACION' => 'FACTURACIÓN',
  'ESTRELLA' => 'ESTRELLA',
  '' => '',
);