<?php 
$app_list_strings['tct_country_list'] = array (
  'MEXICO' => 'MEXICO',
  'ESTADOS UNIDOS' => 'ESTADOS UNIDOS',
);