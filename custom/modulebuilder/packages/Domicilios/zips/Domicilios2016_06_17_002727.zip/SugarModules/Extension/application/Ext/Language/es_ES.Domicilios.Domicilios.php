<?php 
$app_list_strings['tct_address_type_list'] = array (
  'ENVIO' => 'Envío',
  'FACTURACION' => 'Facturación',
  'ESTRELLA' => 'Estrella',
  '' => '',
);$app_list_strings['tct_country_list'] = array (
  'MEXICO' => 'MEXICO',
  'ESTADOS UNIDOS' => 'ESTADOS UNIDOS',
);