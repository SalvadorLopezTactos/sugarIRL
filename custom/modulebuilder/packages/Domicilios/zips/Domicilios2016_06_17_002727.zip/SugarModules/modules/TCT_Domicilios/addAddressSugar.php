<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

class integracionCC {

    function crearDireccion($bean, $event, $arguments) {
    	//Recupera idCC del Cliente: IdCC de Cliente == "" && Id de cliente no es vacio

    	if ($bean->tct_id_cc_customer_txf_c == "" && !empty($bean->contacts_tct_domicilios_1contacts_ida)){
    		//Recupera cliente
    		    $beanCliente = BeanFactory::retrieveBean('Contacts', $bean->contacts_tct_domicilios_1contacts_ida);
          	$bean->tct_id_cc_customer_txf_c = $beanCliente->tct_cc_id_txf_c; //'276792';
    	}
    	//Valida que sea un nuevo registro: idCC de Cliente != "" && Enviado = false
        if ($bean->tct_id_cc_customer_txf_c != "" && $bean->tct_send_address_chk_c == false) {

            $beanCCSetting = BeanFactory::retrieveBean('TCTCC_CCSetting', '1');
            $dns = $beanCCSetting->tct_dns_txf;          //Dominio: http://ec2-52-91-86-51.compute-1.amazonaws.com
            $usuarioT = $beanCCSetting->tct_usert_txf;       //Usuario Token: 'p4g3K13hL5_cc'
            $passwordT = $beanCCSetting->tct_passwordt_txf;    //Password Token: 'cc_W3b2X@rv1s'
            //Url para obtener token
            $urlToken = $dns . ':8080/CCAPI_ANDREA/oauth/token?grant_type=password&client_id=restapp&client_secret=restapp&username=' . $usuarioT . '&password=' . $passwordT;

            //Envia request para Token
            $requestToken = integracionCC::call($urlToken, '', 'POST', '', true, false);
            //Recupera token
            $token = $requestToken->access_token;

            //Parámetros para requst de addAddress
            $usuariClase = $beanCCSetting->tct_userc_txf;     		//Usuario Clase: '4ndr34_cc'
            $passwordClase = $beanCCSetting->tct_passwordc_txf;  	//Contraseña Clase: 'Cli3nt3ccX@rv1s'
            global $current_user;                 					      //Instancia a usuario firmado
            global $app_list_strings;                             //Instancia a LOVs
            $channel = $current_user->tct_channel_ddw_c;     		  //Canal de captación
            //source
            if ($channel == 'POS') {
                $source = 'SugarCRM-Tienda Física';
            } elseif ($channel == 'Call Center') {
                $source = 'SugarCRM-Call Center';
            }
            //$source = 'ANDREA';   //Remover línea, valor de prueba
            
            $country = $app_list_strings['tct_country_list'][$bean->tct_country_ddw];
            $type = $app_list_strings['tct_address_type_list'][$bean->tct_address_type_ddw];

			      //$bean->description = $bean->id;
            $data = array(
                "usuario" => $usuariClase,
                "password" => $passwordClase,
                "idCC" => 0, // $bean->tct_id_cc_customer_txf_c, //Este traerlo de la entidad de clientes
                "sourceID" => $bean->contacts_tct_domicilios_1contacts_ida,
                "source" => $source,
                "streetType" => "", //$bean->tct_address_type_ddw,
                "streetName" => $bean->tct_street_txf,
                "extNumber" => $bean->tct_external_num_txf,
                "intNumber" => $bean->tct_interior_num_txf,
                "postalCode" => $bean->tct_postalcode_txf_c, //$postalCode, //$bean->tct_sepomex_tct_domicilios_1_name,
                "neighborhood" => $bean->tct_colony_txf,
                "county" => $bean->tct_county_txf_c,
                "state" => $bean->tct_state_txf,
                "city" => $bean->tct_city_txf,
                "neighborStreets" => $bean->tct_bt_street_txa,
                "idAddressExt" => $bean->id,
                "country" => $country,
                "sourceRegisterDate" => date("m/d/Y"), //$bean->date_entered,
                "sourceRegisterUpdate" => date("m/d/Y"), //$bean->date_modified,
                "benchmarks" => $bean->tct_reference_txa,
                "addressType" => $type,
                "idAddress" => 0
            );

			$GLOBALS['log']->fatal(print_r($data, true));
            //Genera url para addAddress
            $urladdAddress = $dns.':8080/CCAPI_ANDREA/addAddress?access_token=' . $token;
            $resultadoAddress = integracionCC::call($urladdAddress, '', 'POST', $data, true, false);
            $GLOBALS['log']->fatal(print_r($data, true));
            if ($resultadoAddress != false && $resultadoAddress->error->code == "00") {
                $bean->tct_send_address_chk_c = true;
                $bean->tct_id_cc_address_txf_c = $resultadoAddress->idAddress;
            	  $bean->tct_error_cc_txf_c = $resultadoAddress->error->description;			//Error de integración
                $bean->save();
            }
        }
    }

//Fin funcion crearDireccion

    function call($url, $oauthtoken = '', $type = 'GET', $arguments = array(), $encodeData = true, $returnHeaders = false) {
        $type = strtoupper($type);
        if ($type == 'GET') {
            $url .= "?" . http_build_query($arguments);
        }
        //$url .= "?" . http_build_query('access_token=bbd6aea9-c264-4b45-b4d3-c7941f2af9e');
        $curl_request = curl_init($url);
        if ($type == 'POST') {
            curl_setopt($curl_request, CURLOPT_CUSTOMREQUEST, 'POST');
        } elseif ($type == 'PUT') {
            curl_setopt($curl_request, CURLOPT_CUSTOMREQUEST, "PUT");
        } elseif ($type == 'DELETE') {
            curl_setopt($curl_request, CURLOPT_CUSTOMREQUEST, "DELETE");
        }
        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($curl_request, CURLOPT_HEADER, $returnHeaders);
        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);
        if (!empty($oauthtoken)) {
            $token = array("oauth-token: {$oauthtoken}");
            curl_setopt($curl_request, CURLOPT_HTTPHEADER, $token);
        }
        if (!empty($arguments) && $type !== 'GET') {
            if ($encodeData) {
                //encode the arguments as JSON
                $arguments = json_encode($arguments);
            }
            curl_setopt($curl_request, CURLOPT_POSTFIELDS, $arguments);
            curl_setopt($curl_request, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($arguments))
            );
        }
        $result = curl_exec($curl_request);
        if ($returnHeaders) {
            //set headers from response
            list($headers, $content) = explode("\r\n\r\n", $result, 2);
            foreach (explode("\r\n", $headers) as $header) {
                header($header);
            }
            //return the nonheader data
            return trim($content);
        }
        curl_close($curl_request);
        //decode the response from JSON
        $response = json_decode($result);
        return $response;
    }

//fin funcion call
}

//Fin clase
?>
