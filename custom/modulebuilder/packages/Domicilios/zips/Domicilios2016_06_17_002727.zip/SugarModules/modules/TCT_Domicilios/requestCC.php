<?php

if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

class integracionCC_requestCC {

    function requestCC($bean, $event, $arguments) {
        $bean->tct_request_cc_chk_c = false;
    }//fin funcion call

}//Fin clase
?>
