<?php
// created: 2016-05-13 23:40:21
$subpanel_layout['list_fields'] = array (
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '10%',
    'default' => true,
  ),
  'tct_address_type_ddw' => 
  array (
    'type' => 'enum',
    'default' => true,
    'vname' => 'LBL_TCT_ADDRESS_TYPE_DDW',
    'width' => '10%',
  ),
  'date_modified' => 
  array (
    'vname' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => true,
  ),
);