<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class integracionCC_actualizarDirecciones{
    function actualizarDirecciones($bean, $event, $arguments){
        global $app_list_strings;                             //Instancia a LOVs
        if($bean->tct_id_cc_address_txf_c != "" && $bean->tct_id_cc_customer_txf_c != ""){
        	//Variables de control
            $countFields = 0;                //Contador de campos modificados
            $parametros= array(
                "usuario"=>"",
                "password"=>"",
                "idCC"=>"",
                "field2update"=> array(),
            );                              //Estructura para actualizar

            //Evalua cambios en dirección
            //Tipo
            if($bean->fetched_row['tct_address_type_ddw'] != $bean->tct_address_type_ddw){
                $type = $app_list_strings['tct_address_type_list'][$bean->tct_address_type_ddw];
                $parametros["field2update"][] = array("column"=>"address_type","value"=>$type,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion tipo de direccion

            //País
            if($bean->fetched_row['tct_country_ddw'] != $bean->tct_country_ddw){
                $country = $app_list_strings['tct_country_list'][$bean->tct_country_ddw];
                $parametros["field2update"][] = array("column"=>"country","value"=>$country,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
            	$countFields += 1;
            }//fin condicion pais

            //codigo postal
            if($bean->fetched_row['tct_postalcode_txf_c'] != $bean->tct_postalcode_txf_c){
                $parametros["field2update"][] = array("column"=>"postal_code","value"=>$bean->tct_postalcode_txf_c,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
				$countFields += 1;
            }//fin condicion cod postal mx

            //Estado
            if($bean->fetched_row['tct_state_txf'] != $bean->tct_state_txf){
                $parametros["field2update"][] = array("column"=>"state","value"=>$bean->tct_state_txf,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
       			$countFields += 1;
            }//fin condicion estado

            //Ciudad
            if($bean->fetched_row['tct_city_txf'] != $bean->tct_city_txf){
            	$parametros["field2update"][] = array("column"=>"city","value"=>$bean->tct_city_txf,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion ciudad

            //Colonia
            if($bean->fetched_row['tct_colony_txf'] != $bean->tct_colony_txf){
                $parametros["field2update"][] = array("column"=>"colonia","value"=>$bean->tct_colony_txf,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
            	$countFields += 1;
            }//fin condicion colonia

			//Condado
            if($bean->fetched_row['tct_county_txf_c'] != $bean->tct_county_txf_c){
                $parametros["field2update"][] = array("column"=>"delegacion","value"=>$bean->tct_county_txf_c,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
            	$countFields += 1;
            }//fin condicion colonia


            //Calle
            if($bean->fetched_row['tct_street_txf'] != $bean->tct_street_txf){
                $parametros["field2update"][] = array("column"=>"st_Name","value"=>$bean->tct_street_txf,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion calle

            //Número exterior
            if($bean->fetched_row['tct_external_num_txf'] != $bean->tct_external_num_txf){
            	$parametros["field2update"][] = array("column"=>"st_ext_num","value"=>$bean->tct_external_num_txf,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion numero exterior

            //Número interior
            if($bean->fetched_row['tct_interior_num_txf'] != $bean->tct_interior_num_txf){
            	$parametros["field2update"][] = array("column"=>"st_int_num","value"=>$bean->tct_interior_num_txf,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion numero interior

            //Referencia
            if($bean->fetched_row['tct_reference_txa'] != $bean->tct_reference_txa){
  	      		$parametros["field2update"][] = array("column"=>"benchmarks","value"=>$bean->tct_reference_txa,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion referencia

            //Entre calles
            if($bean->fetched_row['tct_bt_street_txa'] != $bean->tct_bt_street_txa){
       			$parametros["field2update"][] = array("column"=>"st_between","value"=>$bean->tct_bt_street_txa,"type"=>1,"idField"=>$bean->tct_id_cc_address_txf_c);
                $countFields += 1;
            }//fin condicion entre calles

            /*//Fecha de modificación
            if($bean->fetched_row['date_modified'] != $bean->date_modified){
            	$fechaMod=  date_create($bean->date_modified);
                $parametros["field2update"][] = array("column"=>"modified","value"=>date("m/d/Y"),"type"=>4,"idField"=>$bean->tct_id_cc_address_txf_c);
     			$countFields += 1;
            }//fin condicion fecha modificacion
            */

            if($countFields > 0){
            	$beanCCSetting = BeanFactory::retrieveBean('TCTCC_CCSetting', '1');
      				$dns = $beanCCSetting->tct_dns_txf;          //Dominio: http://ec2-52-91-86-51.compute-1.amazonaws.com
      				$usuarioT = $beanCCSetting->tct_usert_txf;       //Usuario Token: 'p4g3K13hL5_cc'
      				$passwordT = $beanCCSetting->tct_passwordt_txf;    //Password Token: 'cc_W3b2X@rv1s'
      				//Url para obtener token
      				$urlToken = $dns . ':8080/CCAPI_ANDREA/oauth/token?grant_type=password&client_id=restapp&client_secret=restapp&username=' . $usuarioT . '&password=' . $passwordT;

      				//Envia request para Token
      				$requestToken = integracionCC_actualizarDirecciones::call($urlToken, '', 'POST', '', true, false);
      				//Recupera token
      				$token = $requestToken->access_token;

      				$usuariClase = $beanCCSetting->tct_userc_txf;     //Usuario Clase: '4ndr34_cc'
      				$passwordClase = $beanCCSetting->tct_passwordc_txf;  //Contraseña Clase: 'Cli3nt3ccX@rv1s'

      				//URL para actualizar dirección
      				$urlUpdate=$dns.":8080/CCAPI_ANDREA/updateIndividual?access_token=".$token;

      				//Setea valores a parámetros
      				$parametros["usuario"]=$usuariClase;
      				$parametros["password"]=$passwordClase;
      				$parametros["idCC"]=intval($bean->tct_id_cc_customer_txf_c);
      				$GLOBALS['log']->fatal(print_r($parametros, true));
      				$result=  integracionCC_actualizarDirecciones::call($urlUpdate,'','POST',$parametros,true,false);
      				$GLOBALS['log']->fatal(print_r($result, true));
      				if($result != false){
      					$bean->tct_error_cc_txf_c=$result->error->code." - ".$result->error->description;
      				}
            }
        }

    }//fin funcion actualizar

    function call($url,$oauthtoken='', $type='GET', $arguments=array(), $encodeData=true, $returnHeaders=false) {
       $type = strtoupper($type);
       if($type == 'GET') { $url .= "?" . http_build_query($arguments); }
       //$url .= "?" . http_build_query('access_token=bbd6aea9-c264-4b45-b4d3-c7941f2af9e');
       $curl_request = curl_init($url);
       if($type == 'POST') { curl_setopt($curl_request, CURLOPT_CUSTOMREQUEST, 'POST'); }
       elseif ($type == 'PUT') { curl_setopt($curl_request, CURLOPT_CUSTOMREQUEST, "PUT"); }
       elseif ($type == 'DELETE') { curl_setopt($curl_request, CURLOPT_CUSTOMREQUEST, "DELETE"); }
       curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
       curl_setopt($curl_request, CURLOPT_HEADER, $returnHeaders);
       curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
       curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);
       if (!empty($oauthtoken)) {
          $token = array("oauth-token: {$oauthtoken}");
          curl_setopt($curl_request, CURLOPT_HTTPHEADER, $token);
       }
       if (!empty($arguments) && $type !== 'GET') {
          if ($encodeData) {
             //encode the arguments as JSON
            $arguments = json_encode($arguments);
          }
          curl_setopt($curl_request, CURLOPT_POSTFIELDS, $arguments);
					curl_setopt($curl_request, CURLOPT_HTTPHEADER, array(
						'Content-Type: application/json',
						'Content-Length: ' . strlen($arguments))
					);
       }
       $result = curl_exec($curl_request);
       if ($returnHeaders) {
          //set headers from response
          list($headers, $content) = explode("\r\n\r\n", $result ,2);
          foreach (explode("\r\n",$headers) as $header) { header($header); }
          //return the nonheader data
          return trim($content);
       }
       curl_close($curl_request);
       //decode the response from JSON
       $response = json_decode($result);
       return $response;
     }//fin funcion call



}//fin clase
