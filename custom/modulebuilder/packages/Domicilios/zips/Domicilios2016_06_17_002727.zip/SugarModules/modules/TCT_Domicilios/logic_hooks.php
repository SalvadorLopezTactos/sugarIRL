<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will
// be automatically rebuilt in the future.
$hook_version = 1;
$hook_array = Array();
// position, file, function
$hook_array['before_save'] = Array();
$hook_array['before_save'][] = Array('10','updateAddress','custom/modules/TCT_Domicilios/updateDireccionesSugar.php','integracionCC_actualizarDirecciones','actualizarDirecciones',);
$hook_array['before_save'][] = Array('12','Limpia bandera requestCC','custom/modules/TCT_Domicilios/requestCC.php','integracionCC_requestCC','requestCC',);
//After save
$hook_array['after_save'] = Array();
$hook_array['after_save'][] = Array('10','addAddress','custom/modules/TCT_Domicilios/addAddressSugar.php','integracionCC','crearDireccion',);




?>
