<?php
 // created: 2016-05-13 23:45:17
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['importable']='false';
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['duplicate_merge']='disabled';
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['duplicate_merge_dom_value']=0;
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['calculated']='1';
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['formula']='ifElse(
equal($tct_country_ddw,"MEXICO"),
related($tct_sepomex_tct_domicilios_1,"tct_colony_txf"),
related($tct_zipcode_tct_domicilios_1,"tct_county_txf")
)';
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['enforced']=true;
$dictionary['TCT_Domicilios']['fields']['tct_colony_txf']['dependency']='equal($tct_country_ddw,"MEXICO")';

 ?>