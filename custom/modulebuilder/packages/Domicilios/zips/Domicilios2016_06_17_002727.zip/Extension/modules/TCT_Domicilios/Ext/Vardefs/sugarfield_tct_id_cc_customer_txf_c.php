<?php
 // created: 2016-05-26 19:20:45
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_customer_txf_c']['labelValue']='Id Cliente CC';
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_customer_txf_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_customer_txf_c']['enforced']='';
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_customer_txf_c']['dependency']='';

 ?>