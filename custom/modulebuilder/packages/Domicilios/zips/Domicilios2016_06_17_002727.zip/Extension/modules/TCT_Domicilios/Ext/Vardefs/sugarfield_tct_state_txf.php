<?php
 // created: 2016-05-06 03:46:26
$dictionary['TCT_Domicilios']['fields']['tct_state_txf']['importable']='false';
$dictionary['TCT_Domicilios']['fields']['tct_state_txf']['duplicate_merge']='disabled';
$dictionary['TCT_Domicilios']['fields']['tct_state_txf']['duplicate_merge_dom_value']=0;
$dictionary['TCT_Domicilios']['fields']['tct_state_txf']['calculated']='true';
$dictionary['TCT_Domicilios']['fields']['tct_state_txf']['formula']='ifElse(
equal($tct_country_ddw,"MEXICO"),
related($tct_sepomex_tct_domicilios_1,"tct_state_txf"),
related($tct_zipcode_tct_domicilios_1,"tct_state_txf")
)';
$dictionary['TCT_Domicilios']['fields']['tct_state_txf']['enforced']=true;

 ?>