<?php
 // created: 2016-06-01 03:42:00
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['duplicate_merge_dom_value']=0;
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['labelValue']='Código postal';
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['calculated']='true';
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['formula']='ifElse(
equal($tct_country_ddw,"MEXICO"),
related($tct_sepomex_tct_domicilios_1,"name"),
related($tct_zipcode_tct_domicilios_1,"name")
)';
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['enforced']='true';
$dictionary['TCT_Domicilios']['fields']['tct_postalcode_txf_c']['dependency']='';

 ?>