<?php
 // created: 2016-05-26 19:22:01
$dictionary['TCT_Domicilios']['fields']['tct_send_address_chk_c']['labelValue']='Dirección enviada';
$dictionary['TCT_Domicilios']['fields']['tct_send_address_chk_c']['enforced']='';
$dictionary['TCT_Domicilios']['fields']['tct_send_address_chk_c']['dependency']='';

 ?>