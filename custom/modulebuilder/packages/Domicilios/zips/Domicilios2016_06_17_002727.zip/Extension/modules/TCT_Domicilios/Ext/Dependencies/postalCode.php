<?php
    $dependencies['TCT_Domicilios']['hidePostalCode'] = array(
        'hooks' => array("edit"),
        'trigger' => 'true', 
        //Check offline
        'triggerFields' => array('tct_country_ddw'),
        'onload' => true,
        'actions' => array(
        //Muestra código postal con base en país
        	//CP MX
            array(
                'name' => 'SetVisibility',
                'params' => array(
                    'target' => 'tct_sepomex_tct_domicilios_1_name',
                    'value' => 'equal($tct_country_ddw, "MEXICO")' 
                )
            ),
            //CP EUA
            array(
                'name' => 'SetVisibility',
                'params' => array(
                    'target' => 'tct_zipcode_tct_domicilios_1_name',
                    'value' => 'equal($tct_country_ddw, "ESTADOS UNIDOS")' 
                )
            ),
            
        ),
        //Actions fire if the trigger is false. Optional.
        'notActions' => array(),
    );