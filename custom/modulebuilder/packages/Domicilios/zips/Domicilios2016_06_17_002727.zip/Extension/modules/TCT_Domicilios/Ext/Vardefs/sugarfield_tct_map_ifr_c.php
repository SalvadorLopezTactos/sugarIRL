<?php
 // created: 2016-06-16 20:51:14
$dictionary['TCT_Domicilios']['fields']['tct_map_ifr_c']['labelValue']='Ubicación';
$dictionary['TCT_Domicilios']['fields']['tct_map_ifr_c']['dependency']='';

 ?>