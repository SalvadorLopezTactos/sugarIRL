<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_TCT_SEPOMEX_TCT_DOMICILIOS_1_FROM_TCT_SEPOMEX_TITLE'] = 'Código Postal MX';
$mod_strings['LBL_TCT_ZIPCODE_TCT_DOMICILIOS_1_FROM_TCT_ZIPCODE_TITLE'] = 'Código Postal EUA';
$mod_strings['LBL_TCT_STATE_TXF'] = 'Estado';
$mod_strings['LBL_TCT_CITY_TXF'] = 'Ciudad';
$mod_strings['LBL_TCT_COLONY_TXF'] = 'Colonia';
$mod_strings['LBL_NAME'] = 'Dirección';
$mod_strings['LBL_TCT_COUNTY_TXF'] = 'Condado';
$mod_strings['LBL_TCT_ID_CC_CUSTOMER_TXF'] = 'Id Cliente CC';
$mod_strings['LBL_TCT_ERROR_CC_TXF'] = 'Error';
$mod_strings['LBL_TCT_SEND_ADDRESS_CHK'] = 'Dirección enviada';
$mod_strings['LBL_TCT_ID_CC_ADDRESS_TXF'] = 'Id Dirección CC';
$mod_strings['LBL_RECORDVIEW_PANEL1'] = 'Nuevo Panel 1';
$mod_strings['LBL_TCT_POSTALCODE_TXF'] = 'Código postal';
$mod_strings['LBL_TCT_REQUEST_CC_CHK'] = 'Request CC';
$mod_strings['LBL_TCT_MAP_IFR'] = 'Ubicación';
$mod_strings['LBL_TCT_DIRECCION_COMPLETA_TXF'] = 'Dirección completa';
