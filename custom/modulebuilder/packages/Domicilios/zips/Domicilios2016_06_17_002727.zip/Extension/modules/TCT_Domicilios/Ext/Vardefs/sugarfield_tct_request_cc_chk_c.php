<?php
 // created: 2016-06-08 18:18:31
$dictionary['TCT_Domicilios']['fields']['tct_request_cc_chk_c']['labelValue']='Request CC';
$dictionary['TCT_Domicilios']['fields']['tct_request_cc_chk_c']['enforced']='';
$dictionary['TCT_Domicilios']['fields']['tct_request_cc_chk_c']['dependency']='';

 ?>