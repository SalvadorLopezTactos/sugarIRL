<?php
 // created: 2016-06-16 20:35:55
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['duplicate_merge_dom_value']=0;
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['labelValue']='Dirección completa';
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['calculated']='1';
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['formula']='ifElse(equal($tct_country_ddw,"ESTADOS UNIDOS"),
concat($tct_state_txf," 
,",$tct_city_txf,",",$tct_street_txf),
concat($tct_state_txf,",",$tct_city_txf,",",$tct_colony_txf,",",$tct_street_txf)
)';
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['enforced']='1';
$dictionary['TCT_Domicilios']['fields']['tct_direccion_completa_txf_c']['dependency']='';

 ?>