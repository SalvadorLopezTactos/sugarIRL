<?php
 // created: 2016-05-06 03:47:08
$dictionary['TCT_Domicilios']['fields']['tct_city_txf']['importable']='false';
$dictionary['TCT_Domicilios']['fields']['tct_city_txf']['duplicate_merge']='disabled';
$dictionary['TCT_Domicilios']['fields']['tct_city_txf']['duplicate_merge_dom_value']=0;
$dictionary['TCT_Domicilios']['fields']['tct_city_txf']['calculated']='true';
$dictionary['TCT_Domicilios']['fields']['tct_city_txf']['formula']='ifElse(
equal($tct_country_ddw,"MEXICO"),
related($tct_sepomex_tct_domicilios_1,"tct_city_txf"),
related($tct_zipcode_tct_domicilios_1,"tct_city_txf")
)';
$dictionary['TCT_Domicilios']['fields']['tct_city_txf']['enforced']=true;

 ?>