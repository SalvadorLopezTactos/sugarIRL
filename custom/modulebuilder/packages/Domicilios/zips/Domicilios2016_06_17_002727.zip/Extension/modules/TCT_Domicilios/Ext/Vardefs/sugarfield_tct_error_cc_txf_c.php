<?php
 // created: 2016-05-26 19:21:21
$dictionary['TCT_Domicilios']['fields']['tct_error_cc_txf_c']['labelValue']='Error';
$dictionary['TCT_Domicilios']['fields']['tct_error_cc_txf_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['TCT_Domicilios']['fields']['tct_error_cc_txf_c']['enforced']='';
$dictionary['TCT_Domicilios']['fields']['tct_error_cc_txf_c']['dependency']='';

 ?>