<?php
 // created: 2016-05-26 19:22:48
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_address_txf_c']['labelValue']='Id Dirección CC';
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_address_txf_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_address_txf_c']['enforced']='';
$dictionary['TCT_Domicilios']['fields']['tct_id_cc_address_txf_c']['dependency']='';

 ?>