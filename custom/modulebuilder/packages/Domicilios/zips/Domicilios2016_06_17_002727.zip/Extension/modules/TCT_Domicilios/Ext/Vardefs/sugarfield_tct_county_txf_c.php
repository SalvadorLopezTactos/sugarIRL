<?php
 // created: 2016-05-13 23:45:57
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['duplicate_merge_dom_value']=0;
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['labelValue']='Condado';
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['calculated']='1';
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['formula']='related($tct_zipcode_tct_domicilios_1,"tct_county_txf")';
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['enforced']='1';
$dictionary['TCT_Domicilios']['fields']['tct_county_txf_c']['dependency']='equal($tct_country_ddw,"ESTADOS UNIDOS")';

 ?>